-- 目标适应症及用药数据分析系统 · 13 接口 MySQL 基准 SQL
-- 杨博文 · T11 · V2.0 · 2026-11-14
-- 口径：application.properties 中 query.engine=mysql；Kylin 方言 SQL 由 KylinUtil 自动改写。
-- 说明：%关键词% 需替换；keyword 为空时删除标注的 IN 子句。
-- 校验：13 条 SQL 已在 MySQL 8.0.44 空表结构上逐条 EXPLAIN 通过（含 drug_code 生成列）。

-- ======================================================================
-- I-01  /home/citylevel  城市等级竞争
SELECT CAST(PRESCRIPTION_DISEASES.YEAR_MONTH AS CHAR) AS year,
       HOSP_AREA.CITY_LEVEL_NAME AS level,
       SUM(PRESCRIPTION_DISEASES.PRICE) AS price,
       SUM(PRESCRIPTION_DISEASES.AMOUNT) AS amount,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
GROUP BY PRESCRIPTION_DISEASES.YEAR_MONTH, HOSP_AREA.CITY_LEVEL_NAME
ORDER BY PRESCRIPTION_DISEASES.YEAR_MONTH, HOSP_AREA.CITY_LEVEL_NAME;

-- ======================================================================
-- I-02  /home/age  不同年龄患病比例
SELECT PRESCRIPTION_DISEASES.m_age AS age,
       PRESCRIPTION_DISEASES.m_sex AS sex,
       SUM(PRESCRIPTION_DISEASES.PRICE) AS price,
       SUM(PRESCRIPTION_DISEASES.AMOUNT) AS amount,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
GROUP BY PRESCRIPTION_DISEASES.m_age, PRESCRIPTION_DISEASES.m_sex
ORDER BY PRESCRIPTION_DISEASES.m_age;

-- ======================================================================
-- I-03  /home/top10  销售金额 Top10
SELECT DRUG.DRUG_GENERIC_NAME AS name,
       SUM(PRESCRIPTION_DISEASES.PRICE) AS price,
       SUM(PRESCRIPTION_DISEASES.AMOUNT) AS amount,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
GROUP BY DRUG.DRUG_GENERIC_NAME
ORDER BY SUM(PRESCRIPTION_DISEASES.AMOUNT) DESC
LIMIT 10;

-- ======================================================================
-- I-04  /home/province  各省份销售格局
SELECT HOSP_AREA.PROVINCE_NAME AS name,
       ROUND(SUM(PRESCRIPTION_DISEASES.PRICE),2) AS price,
       ROUND(SUM(PRESCRIPTION_DISEASES.AMOUNT),2) AS amount,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
GROUP BY HOSP_AREA.PROVINCE_NAME;

-- ======================================================================
-- I-05  /disease/union  目标适应症与药品关联
SELECT DISEASE.DISEASE_TYPE_NAME13 AS diseaseName,
       DRUG.DRUG_GENERIC_NAME AS drugName,
       COUNT(0) AS drugCount
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_disease AS DISEASE
  ON PRESCRIPTION_DISEASES.m_diagnostic1 = DISEASE.DISEASE_TYPE13
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
WHERE 1=1
  -- keyword 为空时删除下一行
  AND DISEASE.DISEASE_TYPE13 IN (SELECT disease_type13 FROM t_view_disease WHERE disease_type_name13 LIKE '%关键词%')
  AND DRUG.DRUG_GENERIC_NAME!=''
GROUP BY DISEASE.DISEASE_TYPE_NAME13, DRUG.DRUG_GENERIC_NAME
ORDER BY COUNT(0) DESC
LIMIT 20;

-- ======================================================================
-- I-06  /disease/drug  药品关联关系图（同 I-05 取数）
-- 与 I-05 使用同一取数 SQL；接口把结果装配为 Nodes / Links。
SELECT DISEASE.DISEASE_TYPE_NAME13 AS diseaseName,
       DRUG.DRUG_GENERIC_NAME AS drugName,
       COUNT(0) AS drugCount
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_disease AS DISEASE
  ON PRESCRIPTION_DISEASES.m_diagnostic1 = DISEASE.DISEASE_TYPE13
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
WHERE 1=1
  -- keyword 为空时删除下一行
  AND DISEASE.DISEASE_TYPE13 IN (SELECT disease_type13 FROM t_view_disease WHERE disease_type_name13 LIKE '%关键词%')
  AND DRUG.DRUG_GENERIC_NAME!=''
GROUP BY DISEASE.DISEASE_TYPE_NAME13, DRUG.DRUG_GENERIC_NAME
ORDER BY COUNT(0) DESC
LIMIT 20;

-- ======================================================================
-- I-07  /disease/age  适应症年龄分布
SELECT PRESCRIPTION_DISEASES.m_age AS age,
       PRESCRIPTION_DISEASES.m_sex AS sex,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_disease AS DISEASE
  ON PRESCRIPTION_DISEASES.m_diagnostic1 = DISEASE.DISEASE_TYPE13
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
WHERE 1=1
  -- keyword 为空时删除下一行
  AND DISEASE.DISEASE_TYPE13 IN (SELECT disease_type13 FROM t_view_disease WHERE disease_type_name13 LIKE '%关键词%')
  AND DRUG.DRUG_GENERIC_NAME!=''
GROUP BY PRESCRIPTION_DISEASES.m_age, PRESCRIPTION_DISEASES.m_sex
ORDER BY COUNT(0) DESC
LIMIT 20;

-- ======================================================================
-- I-08  /disease/section  适应症科室分布
SELECT SECTION.SECTION_NAME1 AS SectionName,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_section AS SECTION
  ON PRESCRIPTION_DISEASES.M_SECTION = SECTION.SECTION2
LEFT JOIN yiyao.t_view_disease AS DISEASE
  ON PRESCRIPTION_DISEASES.m_diagnostic1 = DISEASE.DISEASE_TYPE13
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
WHERE 1=1
  -- keyword 为空时删除下一行
  AND DISEASE.DISEASE_TYPE13 IN (SELECT disease_type13 FROM t_view_disease WHERE disease_type_name13 LIKE '%关键词%')
  AND DRUG.DRUG_GENERIC_NAME!=''
GROUP BY SECTION.SECTION_NAME1
LIMIT 20;

-- ======================================================================
-- I-09  /drug/cities  城市用药分布
SELECT HOSP_AREA.CITY_NAME AS name,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
WHERE 1=1
  -- keyword 为空时删除下一行
  AND DRUG.DRUG IN (SELECT drug FROM t_view_drug WHERE package_chinese_name LIKE '%关键词%')
  AND DRUG.DRUG_GENERIC_NAME!='' AND HOSP_AREA.CITY_NAME!=''
GROUP BY HOSP_AREA.CITY_NAME;

-- ======================================================================
-- I-10  /drug/hospital  药品与医院等级分布
SELECT DRUG.DRUG_GENERIC_NAME AS drug,
       HOSPITAL.HOSP_GRADE_NAME AS grade,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
LEFT JOIN yiyao.t_view_hosp AS HOSPITAL
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSPITAL.HOSP_ID
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
WHERE 1=1
  -- keyword 为空时删除下一行
  AND DRUG.DRUG IN (SELECT drug FROM t_view_drug WHERE package_chinese_name LIKE '%关键词%')
  AND DRUG.DRUG_GENERIC_NAME!=''
GROUP BY DRUG.DRUG_GENERIC_NAME, HOSPITAL.HOSP_GRADE_NAME
LIMIT 20;

-- ======================================================================
-- I-11  /drug/diseases  药品对应适应症
SELECT DRUG.DRUG_GENERIC_NAME AS drug,
       DISEASE.DISEASE_TYPE_NAME13 AS disease,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
LEFT JOIN yiyao.t_view_disease AS DISEASE
  ON PRESCRIPTION_DISEASES.m_diagnostic1 = DISEASE.DISEASE_TYPE13
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
WHERE 1=1
  -- keyword 为空时删除下一行
  AND DRUG.DRUG IN (SELECT drug FROM t_view_drug WHERE package_chinese_name LIKE '%关键词%')
  AND DRUG.DRUG_GENERIC_NAME!=''
GROUP BY DRUG.DRUG_GENERIC_NAME, DISEASE.DISEASE_TYPE_NAME13
ORDER BY COUNT(0) DESC
LIMIT 20;

-- ======================================================================
-- I-12  /drug/section  药品科室分布
SELECT DRUG.DRUG_GENERIC_NAME AS drug,
       SECTION.SECTION_NAME1 AS section,
       COUNT(0) AS counter
FROM yiyao.prescription_diseases AS PRESCRIPTION_DISEASES
LEFT JOIN yiyao.t_view_drug AS DRUG
  ON PRESCRIPTION_DISEASES.drug_code = DRUG.DRUG
LEFT JOIN yiyao.t_view_section AS SECTION
  ON PRESCRIPTION_DISEASES.M_SECTION = SECTION.SECTION2
INNER JOIN yiyao.t_view_areas AS HOSP_AREA
  ON PRESCRIPTION_DISEASES.HOSP_ID = HOSP_AREA.HOSP_ID
WHERE 1=1
  -- keyword 为空时删除下一行
  AND DRUG.DRUG IN (SELECT drug FROM t_view_drug WHERE package_chinese_name LIKE '%关键词%')
  AND DRUG.DRUG_GENERIC_NAME!=''
GROUP BY DRUG.DRUG_GENERIC_NAME, SECTION.SECTION_NAME1
ORDER BY COUNT(0) DESC
LIMIT 20;

-- ======================================================================
-- I-13  /home/overview  首页概览指标
SELECT COUNT(1) AS rowsCnt,
       SUM(AMOUNT) AS totalAmount,
       COUNT(DISTINCT HOSP_ID) AS hospCnt
FROM yiyao.prescription_diseases;

SELECT (SELECT COUNT(*) FROM yiyao.t_view_drug) AS DRUG_CNT,
       (SELECT COUNT(*) FROM yiyao.t_view_disease) AS DISEASE_CNT,
       (SELECT COUNT(DISTINCT city) FROM yiyao.t_view_areas) AS CITY_CNT;
